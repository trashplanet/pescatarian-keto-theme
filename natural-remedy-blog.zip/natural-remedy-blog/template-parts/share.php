<?php 
	$share_url = get_the_permalink();

	$share_title = get_the_title();

	$share_post = $share_title.' '.$share_url;

	$share_image = get_the_post_thumbnail_url();

	$tweet = $share_title.' '.$share_url.' @herbalismsblog';

	$tweet_href = 'https://twitter.com/home?status='.urlencode($tweet);

	$facebook_href = 'https://www.facebook.com/sharer/sharer.php?u='.htmlspecialchars($share_url);

	$linkedin_href = 'https://www.linkedin.com/shareArticle?mini=true&url='.urlencode($share_url).'&title='.urlencode($share_title);

	$googleplus_href = 'https://plus.google.com/share?url='.htmlspecialchars($share_url);

	$pinterest_href = 'https://pinterest.com/pin/create/button/?url='.htmlspecialchars($share_url).'&media='.urlencode($share_image);

	$email_href = 'mailto:?&subject=Check this out: '.htmlspecialchars($share_title).'&body=Read '.htmlspecialchars($share_title).' here: '.htmlspecialchars($share_url);
?> 
<div class="social-share-icons">
	<h6>Share this article:</h6>
	<a href="<?php echo $tweet_href; ?>">twitter</a>
	<a href="<?php echo $facebook_href; ?>">facebook</a>
	<a href="<?php echo $linkedin_href; ?>">linkedin</a>
	<a href="<?php echo $googleplus_href; ?>">google+</a>
	<a href="<?php echo $pinterest_href; ?>">pinterest</a>
	<a href="<?php echo $email_href; ?>">email</a>
</div>