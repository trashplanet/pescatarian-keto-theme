<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Natural_Remedy_Blog
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php
		if ( is_singular() ) :
			//no entry title for single pages
			;
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) : ?>
		<div class="entry-meta">
			<?php 
				if ( is_single() ) :
					//display nothing if single
					;
				else :
					natural_remedy_blog_posted_on(); 
				endif;
			?> 
		</div>
		<?php
		endif; ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<div class="featured-image-container">
			<a href="<?php echo get_permalink(); ?>">
				<?php
					if ( has_post_thumbnail() ) {
						the_post_thumbnail();
					} 
				?>
			</a>
		</div>
		<?php
			the_content( sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'natural-remedy-blog' ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				get_the_title()
			) );

			//recipe
			if (is_single()) {
				$has_recipe = get_field('name');
				if ($has_recipe){
					get_template_part( 'template-parts/recipe');
				}
			}

			//jetpack share links

			if ( function_exists( 'sharing_display' ) ) {
			    sharing_display( '', true );
			}
			 
			if ( class_exists( 'Jetpack_Likes' ) ) {
			    $custom_likes = new Jetpack_Likes;
			    echo $custom_likes->post_likes( '' );
			}

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'natural-remedy-blog' ),
				'after'  => '</div>',
			) );

			//jetpack related posts

			echo do_shortcode( '[jetpack-related-posts]' );
		?>
	</div><!-- .entry-content -->
	<!--shop related products-->
	<div class="shop-related-products columns large-12">
		<?php 
			if (is_single()) {
				the_field('related-products');
			} 
		?>
	</div>
	<footer class="entry-footer">
		<?php natural_remedy_blog_entry_footer(); ?>
	</footer><!-- .entry-footer -->
	<hr/>
</article><!-- #post-<?php the_ID(); ?> -->
