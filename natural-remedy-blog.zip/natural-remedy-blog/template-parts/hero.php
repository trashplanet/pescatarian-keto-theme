<section id="hero">
	<div class="hero-inner">
		<div class="row">
			<div class="large-12 medium-12 columns text-center">
				<h1 class="site-title">
					<?php
						$search_query = get_search_query(); 
						if( is_front_page() ){
							echo 'The Pescatarian Keto Blog';
						}
						elseif ( is_archive() ){
							echo str_replace("Category: ", "", get_the_archive_title());
						}
						elseif( is_search() ){
							echo 'Search results for "'.$search_query.'"';
						}
						elseif( is_404() ){
							echo '404: Nothing Found';
						}
						else{
							the_title();
						}
					?>
				</h1>
				<!--subtitle on homepage-->
				<?php
					$description = get_bloginfo( 'description', 'display' );
					if( is_front_page() ) :
						if ( $description || is_customize_preview() ) : ?>
							<p class="subtitle"><?php echo $description; /* WPCS: xss ok. */ ?></p>
						<?php 
						endif;
					endif;
				?>
				<!--custom fields for subtitles on archive pages-->
				<?php 
					if( is_archive() ) {
						// load all 'category' terms for the post
						$queried_object = get_queried_object(); 
						$taxonomy = $queried_object->taxonomy;
						$term_id = $queried_object->term_id;  

						$subtitle = get_field('subtitle', $taxonomy . '_' . $term_id);

						if($subtitle) : ?>
						<p class="subtitle"><?php echo $subtitle ?></p>
						<?php	
						endif;
					}
				?>
				<!--custom fields for subtitles on single posts and pages-->
				<?php
					if( is_single() || is_page() ) : 
						if ( get_field('subtitle') ) : ?>
							<p class="subtitle"><?php the_field('subtitle'); ?></p>
						<?php 
						endif;
					endif;
				?>
				<!--entry meta-->
				<?php
					if( is_single() ) : ?>
						<div class="entry-meta">
							<?php natural_remedy_blog_posted_on(); ?>
						</div>
					<?php
					endif;
				?>
			</div>
		</div>
	</div>
</section>