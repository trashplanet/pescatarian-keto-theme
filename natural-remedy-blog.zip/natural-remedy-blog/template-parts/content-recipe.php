<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Natural_Remedy_Blog
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php
		if ( is_singular() ) :
			//no entry title for single pages
			;
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) : ?>
		<!-- <div class="entry-meta">
			<?php natural_remedy_blog_posted_on(); ?>
		</div> -->
		<?php
		endif; ?>
	</header><!-- .entry-header -->

	<div class="entry-content recipe-content">
		<div class="featured-image-container">
			<a href="<?php echo get_permalink(); ?>">
				<?php
					if ( has_post_thumbnail() ) {
						the_post_thumbnail();
					} 
				?>
			</a>
		</div>
		<?php
			the_content( sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'natural-remedy-blog' ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				get_the_title()
			) );

			// recipe custom fields

			$description = get_field('description');

			// time

			$preptime = get_field('preptime');
			$cooktime = get_field('cooktime');
			$totaltime = get_field('totaltime');

			if($preptime || $cooktime || $totaltime):?>

				<div class="recipe-time">

					<?php if($preptime) echo '<div class="prep-time">Prep Time: '.$preptime.'</div>'; ?>
					<?php if($cooktime) echo '<div class="cook-time">Cook Time: '.$cooktime.'</div>'; ?>
					<?php if($totaltime) echo '<div class="total-time">Total Time: '.$totaltime.'</div>'; ?>

				</div>

			<?php endif;

			//yield
			$recipeyield = get_field('recipeyield');

			if($recipeyield):?>

				<div class="recipe-yield">

					<?php if($recipeyield) echo '<div class="recipeyield">Yield: '.$recipeyield.'</div>'; ?>

				</div>

			<?php endif;

			//nutrition

			$nutrition = get_field('nutrition');

			if($nutrition):?>

				<div class="nutrition">

					<h3>Nutrition Facts</h3>

					<?php if($nutrition['servingsize']) echo '<div class="serving-size">Serving Size: '.$nutrition['servingsize'].'</div>'; ?>
					<?php if($nutrition['calories']) echo '<div class="calories">Calories: '.$nutrition['calories'].'</div>'; ?>
					<?php if($nutrition['fatcontent']) echo '<div class="fat-content">Fat: '.$nutrition['fatcontent'].'</div>'; ?>
					<?php if($nutrition['proteincontent']) echo '<div class="protein-content">Protein: '.$nutrition['proteincontent'].'</div>'; ?>
					<?php if($nutrition['totalcarbs']) echo '<div class="carbohydrate-content">Total Carbs: '.$nutrition['totalcarbs'].'</div>'; ?>
					<?php if($nutrition['carbohydratecontent']) echo '<div class="carbohydrate-content">Net Carbs: '.$nutrition['carbohydratecontent'].'</div>'; ?>
					<?php if($nutrition['sugaralcohols']) echo '<div class="sugar-alcohols">Sugar Alcohols: '.$nutrition['sugaralcohols'].'</div>'; ?>
					<?php if($nutrition['fibercontent']) echo '<div class="fiber-content">Fiber: '.$nutrition['fibercontent'].'</div>'; ?>
					<?php if($nutrition['cholesterolcontent']) echo '<div class="cholesterol-content">Cholesterol: '.$nutrition['cholesterolcontent'].'</div>'; ?>
					<?php if($nutrition['saturatedfatcontent']) echo '<div class="saturatedfatcontent">Saturated Fat: '.$nutrition['saturatedfatcontent'].'</div>'; ?>
					<?php if($nutrition['sodiumcontent']) echo '<div class="sodium-content">Sodium: '.$nutrition['sodiumcontent'].'</div>'; ?>
					<?php if($nutrition['sugarcontent']) echo '<div class="sugar-content">Sugar: '.$nutrition['sugarcontent'].'</div>'; ?>
					<?php if($nutrition['transfatcontent']) echo '<div class="trans-fat-content">Trans Fat: '.$nutrition['transfatcontent'].'</div>'; ?>

				</div>

			<?php endif;

			//ingredients

			if( have_rows('recipeingredient') ) : ?>

			<div class="ingredients">
				<h3>Ingredients</h3>
				<ul>

				 	<?php while ( have_rows('recipeingredient') ) : the_row();

				        // display a sub field value
				        echo '<li class="ingredient">'.get_sub_field('ingredient').'</li>';

				    endwhile; ?>
				    
			    </ul>
			</div>

			<?php endif;

			//instructions

			if( have_rows('recipeinstructions') ) : ?>

			<div class="instructions">
				<h3>Instructions</h3>
				<ol>

				 	<?php while ( have_rows('recipeinstructions') ) : the_row();

				        // display a sub field value
				        echo '<li class="instruction">'.get_sub_field('instruction').'</li>';

				    endwhile; ?>

				</ol>
			</div>

			<?php endif;

		?>
	</div><!-- .entry-content -->
	<!--shop related products-->
	<div class="shop-related-products columns large-12">
		<?php the_field('related-products'); ?>
	</div>
	<footer class="entry-footer">
		<?php natural_remedy_blog_entry_footer(); ?>
	</footer><!-- .entry-footer -->
	<hr/>
</article><!-- #post-<?php the_ID(); ?> -->
