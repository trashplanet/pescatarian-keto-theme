<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Natural_Remedy_Blog
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<div class="sidebar" data-sticky-container>
	<div class="sticky" data-sticky data-stick-to="bottom" data-top-anchor="primary" data-btm-anchor="content-area:bottom">
		<aside id="secondary" class="widget-area">
			<div class="sidebar-box">
				<div class="social-follow">
					<h2>Follow Us</h2>
					<a href="https://twitter.com/PescatarianKeto" rel="me" target="_blank"><img class="social-icon" alt="Twitter Icon" src="<?php echo get_template_directory_uri() ?>/img/twitter-icon.png"></a><a href="https://www.pinterest.com/pescatarianketo/" rel="me" target="_blank"><img class="social-icon" alt="Pinterest Icon" src="<?php echo get_template_directory_uri() ?>/img/pinterest-icon.png"></a></br>
				</div>
				<!--wordpress sidebar widget-->
				<?php dynamic_sidebar( 'sidebar-1' ); ?>
				<div class="affiliate-disclosure">
					<h2>Affiliate Disclosure</h2>
					<span>This website uses affiliate links, which means that I may get compensated if you click a link to a product featured here and buy it.</span>
				</div>
				<h2>Keto Products I Love</h2>
				<!--perfect keto-->
				<div class="perfect-keto favorite-image">
					<script type="text/javascript" src="//cdn.refersion.com/creative.js"></script>
					<script>$rfsn_creative.generate('refersion_client/16689/creatives/dynamic/26125-9fb3aa589686ec1a6f08238377a0bda3.json', {
						aid: '1140318.b1977c'
					});</script><div id="rfsn_img_26125"></div>	
					<div class="favorite-link">
						<span><a href="https://shop.perfectketo.com?rfsn=1140318.b1977c&utm_source=refersion&utm_medium=affiliate&utm_campaign=1140318.b1977c" target="_blank">Use the code KETOTIME15</a> for 15% off your Perfect Keto order! Check out my <a href="http://pescatarianketo.com/reviews/perfect-keto-base-exogenous-ketones/">review of Perfect Keto's exogenous ketones</a> to learn more.</span>
					</div>
				</div>
				<!--keto bars-->
				<div class="keto-favorites favorite-image">
					<div class="favorite-image">
						<a href="http://www.ketobars.com?aff=121" rel="nofollow"><img src="https://www.affiliatly.com/affiliate_files/banners/6135/IBIHSideOption2.jpg" width="300" height="300" alt="" /></a>
					</div>
					<div class="favorite-link">
						<span>Check out my <a href="http://pescatarianketo.com/reviews/keto-bars/">Keto Bars review</a>!</span>
					</div>
				</div>
				<!--keto kookie-->
				<div class="keto-favorites favorite-image">
					<script type="text/javascript" src="//cdn.refersion.com/creative.js"></script>
					<script>$rfsn_creative.generate('refersion_client/21116/creatives/dynamic/29553-aa16ecf6f7122790f1188cd4b928b8ec.json', {
						aid: '1143244.778a04'
					});</script><div id="rfsn_img_29553"></div>
				</div>
				<!--four sigmatic shrooms-->
				<div class="keto-favorites">
					<div class="favorite-item">
						<h2>My Favorite Nootropics</h2>
						<div class="favorite-image">
							<a href='http://www.us.foursigmatic.com/#_a_fishyketo'><img src='http://pescatarianketo.com/wp-content/uploads/2018/03/shop-mushroom-elixers.jpg'/></a>
						</div>
						<div class="favorite-link">
							<a href='http://www.us.foursigmatic.com/#_a_fishyketo'>Use my discount code FISHYKETO</a> for 10% off medicinal mushrooms!
						</div>
					</div>
				</div>
				<!--my pescatarian keto staples-->
				<h2>My Pescatarian Keto Staples</h2>
					<div class="my-recommended-products">
						<div class="row text-center sameheight-wrap">
							<div class="product-box">
								<div class="product-box-img-container">
									<a href="https://www.amazon.com/NOW-MCT-100%25-Oil-32-Ounce/dp/B0019LRY8A/ref=as_li_ss_il?adId=B0019LRY8A&ref-refURL=http://localhost:8080/wordpress/&slotNum=0&imprToken=2919687338189395%7C1522718066&adType=smart&adMode=manual&adFormat=grid&impressionTimestamp=1522718066281&linkCode=li2&tag=pescatarianke-20&linkId=0eb38c49aec0a0a8c8cf7d99e75aaffe" target="_blank" data-label="Sidebar - NOW Sports MCT Oil - Image"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B0019LRY8A&Format=_SL160_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=pescatarianke-20" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=pescatarianke-20&l=li2&o=1&a=B0019LRY8A" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
								</div>
								<div class="sameheight">
									<a href="https://www.amazon.com/NOW-MCT-100%25-Oil-32-Ounce/dp/B0019LRY8A/ref=as_li_ss_tl?adId=B0019LRY8A&ref-refURL=http://localhost:8080/wordpress/&slotNum=0&imprToken=2919687338189395%7C1522718066&adType=smart&adMode=manual&adFormat=grid&impressionTimestamp=1522718066281&linkCode=ll1&tag=pescatarianke-20&linkId=a72a0721bc750815bab6943c44f7b70c" target="_blank" data-label="Sidebar - NOW Sports MCT Oil - Text">Now Sports MCT Oil</a>
								</div>
								<div>
									<a class="button" href="https://www.amazon.com/NOW-MCT-100%25-Oil-32-Ounce/dp/B0019LRY8A/ref=as_li_ss_tl?adId=B0019LRY8A&ref-refURL=http://localhost:8080/wordpress/&slotNum=0&imprToken=2919687338189395%7C1522718066&adType=smart&adMode=manual&adFormat=grid&impressionTimestamp=1522718066281&linkCode=ll1&tag=pescatarianke-20&linkId=a72a0721bc750815bab6943c44f7b70c" target="_blank" data-label="Sidebar - NOW Sports MCT Oil - Button">Buy Now</a>
								</div>
							</div>
							<div class="product-box">
								<div class="product-box-img-container">
									<a href="https://www.amazon.com/Exogenous-Ketone-Performance-Complex-Beta-Hydroxybutyrates/dp/B07175TLCN/ref=as_li_ss_il?adId=B07175TLCN&ref-refURL=http://pescatarianketo.com/&slotNum=0&imprToken=271682352096740%7C1522728791&adType=smart&adMode=manual&adFormat=grid&impressionTimestamp=1522728791460&linkCode=li2&tag=pescatarianke-20&linkId=0d5864443c1034604d245934c94f0bbe" target="_blank" data-label="Sidebar - Keto Drive BHB Salts - Image"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B07175TLCN&Format=_SL160_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=pescatarianke-20" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=pescatarianke-20&l=li2&o=1&a=B07175TLCN" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
								</div>
								<div class="sameheight">
									<a href="https://www.amazon.com/Exogenous-Ketone-Performance-Complex-Beta-Hydroxybutyrates/dp/B07175TLCN/ref=as_li_ss_tl?adId=B07175TLCN&ref-refURL=http://pescatarianketo.com/&slotNum=0&imprToken=271682352096740%7C1522728791&adType=smart&adMode=manual&adFormat=grid&impressionTimestamp=1522728791460&linkCode=ll1&tag=pescatarianke-20&linkId=027052e7f4bbfde9a0e54daaa5c7759b" target="_blank" data-label="Sidebar - Keto Drive BHB Salts - Text">Keto Drive BHB Salts</a>
								</div>
								<div>
									<a class="button" href="https://www.amazon.com/Exogenous-Ketone-Performance-Complex-Beta-Hydroxybutyrates/dp/B07175TLCN/ref=as_li_ss_tl?adId=B07175TLCN&ref-refURL=http://pescatarianketo.com/&slotNum=0&imprToken=271682352096740%7C1522728791&adType=smart&adMode=manual&adFormat=grid&impressionTimestamp=1522728791460&linkCode=ll1&tag=pescatarianke-20&linkId=027052e7f4bbfde9a0e54daaa5c7759b" target="_blank" data-label="Sidebar - Keto Drive BHB Salts - Button">Buy Now</a>
								</div>
							</div>
						</div>
						<div class="row text-center sameheight2-wrap">
							<div class="product-box">
								<div class="product-box-img-container">
									<a href="https://www.amazon.com/Perfect-Keto-Testing-Ketosis-Ketogenic/dp/B01MUB7BUV/ref=as_li_ss_il?s=hpc&ie=UTF8&qid=1522729325&sr=1-1-spons&keywords=perfect+keto+test+strips&psc=1&linkCode=li2&tag=pescatarianke-20&linkId=6aa222c48e880a5baffb2dd26d26cac3" target="_blank" data-label="Sidebar - Perfect Keto Ketone Testing Strips - Image"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B01MUB7BUV&Format=_SL160_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=pescatarianke-20" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=pescatarianke-20&l=li2&o=1&a=B01MUB7BUV" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
								</div>
								<div class="sameheight2">
									<a href="https://www.amazon.com/Perfect-Keto-Testing-Ketosis-Ketogenic/dp/B01MUB7BUV/ref=as_li_ss_tl?s=hpc&ie=UTF8&qid=1522729325&sr=1-1-spons&keywords=perfect+keto+test+strips&psc=1&linkCode=ll1&tag=pescatarianke-20&linkId=83d00f60926afc9e17c1e727d175e131" target="_blank" data-label="Sidebar - Perfect Keto Ketone Testing Strips - Text">Perfect Keto Ketone Testing Strips</a>
								</div>
								<div>
									<a class="button" href="https://www.amazon.com/Perfect-Keto-Testing-Ketosis-Ketogenic/dp/B01MUB7BUV/ref=as_li_ss_tl?s=hpc&ie=UTF8&qid=1522729325&sr=1-1-spons&keywords=perfect+keto+test+strips&psc=1&linkCode=ll1&tag=pescatarianke-20&linkId=83d00f60926afc9e17c1e727d175e131" target="_blank" data-label="Sidebar - Perfect Keto Ketone Testing Strips - Button">Buy Now</a>
								</div>
							</div>
							<div class="product-box">
								<div class="product-box-img-container">
									<a href="https://www.amazon.com/Wild-Planet-Sardines-Extra-Virgin/dp/B004UB6HAC/ref=as_li_ss_il?s=hpc&ie=UTF8&qid=1522729466&sr=1-1-spons&keywords=wild+planet+sardines&th=1&linkCode=li2&tag=pescatarianke-20&linkId=53e238b9aaa1aebe73fddac2f9ce95fd" target="_blank" data-label="Sidebar - Wild Planet Sardines - Image"><img border="0" src="//ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B004UB6HAC&Format=_SL160_&ID=AsinImage&MarketPlace=US&ServiceVersion=20070822&WS=1&tag=pescatarianke-20" ></a><img src="https://ir-na.amazon-adsystem.com/e/ir?t=pescatarianke-20&l=li2&o=1&a=B004UB6HAC" width="1" height="1" border="0" alt="" style="border:none !important; margin:0px !important;" />
								</div>
								<div class="sameheight2">
									<a href="https://www.amazon.com/Wild-Planet-Sardines-Extra-Virgin/dp/B004UB6HAC/ref=as_li_ss_tl?s=hpc&ie=UTF8&qid=1522729466&sr=1-1-spons&keywords=wild+planet+sardines&th=1&linkCode=ll1&tag=pescatarianke-20&linkId=10b3533b1e933f3ec9f27d27eb88394e" target="_blank" data-label="Sidebar - Wild Planet Sardines - Text">Wild Planet Sardines in Extra Virgin Olive Oil</a>
								</div>
								<div>
									<a class="button" href="https://www.amazon.com/Wild-Planet-Sardines-Extra-Virgin/dp/B004UB6HAC/ref=as_li_ss_tl?s=hpc&ie=UTF8&qid=1522729466&sr=1-1-spons&keywords=wild+planet+sardines&th=1&linkCode=ll1&tag=pescatarianke-20&linkId=10b3533b1e933f3ec9f27d27eb88394e" target="_blank" data-label="Sidebar - Wild Planet Sardines - Button">Buy Now</a>
								</div>
							</div>
						</div>
					</div>
				</div>
		</aside><!-- #secondary -->
	</div>
</div>
