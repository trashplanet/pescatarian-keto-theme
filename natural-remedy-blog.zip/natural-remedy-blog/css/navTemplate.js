// Initialize the nav scripts
jQuery("ul.navTemplate").ready(function(){
	jQuery('ul.menu.navTemplate').addClass('styleOverlay');
    // close all nav
    function closeNav(){
        jQuery(".navContainer, .navContainer *").removeClass("active");
    }
    jQuery("body").click(function(event){
        // if you click out of the nav
        if(jQuery(event.target).parents(".navContainer").length < 1){
            closeNav();
        }
    });
    // if you click a link
    jQuery("ul.navTemplate a[href]").click(function(){
        closeNav();
    });
    // toggle active class, used for mobile expand
    jQuery(".navTemplateControl").click(function(){
        jQuery(".navContainer").toggleClass("active");
    });
    // first level links
    jQuery("ul.navTemplate > li:has(ul) > a").click(function(){
        // close all other second level
        jQuery("ul.navTemplate > li:has(ul)").not(jQuery(this).parent("li")).removeClass("active");
        // close all thrid level
        jQuery("ul.navTemplate li > ul > li:has(ul)").removeClass("active");
        jQuery(this).parent("li").toggleClass("active");
    });
    // second level links
    jQuery("ul.navTemplate li > ul > li:has(ul) > a").click(function(){
        // close all other thrid level
        jQuery("ul.navTemplate li > ul > li:has(ul)").not(jQuery(this).parent("li")).removeClass("active");
        jQuery(this).parent("li").toggleClass("active");
    });
    // add identifying class for nested list
    jQuery(".navTemplate a").each(function(){
        if(jQuery(this).next().is("ul")){
            jQuery(this).addClass("hasSubNav");
        }
    });
});