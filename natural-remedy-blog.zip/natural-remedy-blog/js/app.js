(function($){
	$(document).foundation();
	//make sidebar products the same height
	function sameheight(){
		if($('.sameheight')[0]){
			equalheight('.sameheight-wrap .sameheight');
		}
		if($('.sameheight2')[0]){
			equalheight('.sameheight2-wrap .sameheight2');
		}
    }
    $(window).load(function() {
       sameheight();
    });
    $(window).resize(function(){
       sameheight();
    });

	//amazon link tracking
	$('a[href^="https://www.amazon.com"]').bind('click', function(){
		//default label to be href value
		var label = $(this).attr('href');
		//use data label if data label has been set
		if(typeof $(this).attr('data-label') !== 'undefined'){
			label = $(this).attr('data-label');
		}
		//use text value if it is text link
		else if(typeof $(this).text() !== 'undefined'){
			label = $(this).text();
		}
		gtag('event', 'click', {
			'send_to': 'UA-115463665-1',
			'event_category': 'Amazon Link Click',
			'event_label': label
		});
	});

	//perfect keto shop link tracking
	$('a[href^="https://shop.perfectketo.com"]').bind('click', function(){
		//default label to be href value
		var label = $(this).attr('href');
		//use data label if data label has been set
		if(typeof $(this).attr('data-label') !== 'undefined'){
			label = $(this).attr('data-label');
		}
		//use text value if it is text link
		else if(typeof $(this).text() !== 'undefined'){
			label = $(this).text();
		}
		gtag('event', 'click', {
			'send_to': 'UA-115463665-1',
			'event_category': 'Perfect Keto Shop Link Click',
			'event_label': label
		});
	});

	//keto bars link tracking
	$('a[href^="https://www.ketobars.com"]').bind('click', function(){
		//default label to be href value
		var label = $(this).attr('href');
		//use data label if data label has been set
		if(typeof $(this).attr('data-label') !== 'undefined'){
			label = $(this).attr('data-label');
		}
		//use text value if it is text link
		else if(typeof $(this).text() !== 'undefined'){
			label = $(this).text();
		}
		gtag('event', 'click', {
			'send_to': 'UA-115463665-1',
			'event_category': 'Keto Bars Link Click',
			'event_label': label
		});
	});

	//keto kookie link tracking
	$('a[href^="https://ketokookie.com"]').bind('click', function(){
		//default label to be href value
		var label = $(this).attr('href');
		//use data label if data label has been set
		if(typeof $(this).attr('data-label') !== 'undefined'){
			label = $(this).attr('data-label');
		}
		//use text value if it is text link
		else if(typeof $(this).text() !== 'undefined'){
			label = $(this).text();
		}
		gtag('event', 'click', {
			'send_to': 'UA-115463665-1',
			'event_category': 'Keto Kookie Link Click',
			'event_label': label
		});
	});
    
})(jQuery);